/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Main;


public class BasicArithmeticOparation {

    
    public static void main(String[] args) {
        int Number1=10;
        int Number2=11;
        
        float Avarage=(float)(Number1+Number2)/2;
        System.out.println("Avarage"+Avarage);
       
    }
    
}
